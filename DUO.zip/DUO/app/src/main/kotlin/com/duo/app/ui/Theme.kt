package com.duo.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Only the Midnight theme exists so far. Light, Neon and Custom are NOT implemented. */
private val MidnightColors = darkColorScheme(
    primary = Color(0xFF8AB4FF),
    onPrimary = Color(0xFF06142B),
    secondaryContainer = Color(0xFF2A3342),
    onSecondaryContainer = Color(0xFFDDE6F5),
    background = Color(0xFF0E1116),
    onBackground = Color(0xFFE6EAF0),
    surface = Color(0xFF161B22),
    onSurface = Color(0xFFE6EAF0),
)

@Composable
fun DuoTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = MidnightColors, content = content)
}
