package com.duo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.duo.app.editor.EditorScreen
import com.duo.app.ui.DuoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DuoTheme {
                EditorScreen()
            }
        }
    }
}
