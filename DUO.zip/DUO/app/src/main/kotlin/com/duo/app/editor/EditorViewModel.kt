package com.duo.app.editor

import androidx.lifecycle.ViewModel
import com.duo.core.commands.AddClip
import com.duo.core.commands.Command
import com.duo.core.commands.CommandException
import com.duo.core.commands.CommandHistory
import com.duo.core.commands.DeleteClip
import com.duo.core.commands.SplitClip
import com.duo.core.commands.TrimClip
import com.duo.core.model.Clip
import com.duo.core.model.Project
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface ExportState {
    data object Idle : ExportState
    data object Running : ExportState
    data object Done : ExportState
    data class Failed(val reason: String) : ExportState
}

data class EditorUiState(
    val project: Project,
    val selectedClipId: String?,
    val canUndo: Boolean,
    val canRedo: Boolean,
    val message: String?,
    val export: ExportState,
)

/** Holds the project and routes every edit through the command system. */
class EditorViewModel : ViewModel() {

    private val history = CommandHistory()
    private var selectedClipId: String? = null
    private var message: String? = null
    private var export: ExportState = ExportState.Idle
    private var nextClipNumber = 1

    private val _state = MutableStateFlow(buildState())
    val state: StateFlow<EditorUiState> = _state.asStateFlow()

    private fun buildState(): EditorUiState {
        val project = history.current
        val selected = selectedClipId
        if (selected != null && project.findClip(selected) == null) selectedClipId = null
        return EditorUiState(project, selectedClipId, history.canUndo, history.canRedo, message, export)
    }

    private fun publish() {
        _state.value = buildState()
    }

    private fun newClipId(): String = "clip-${nextClipNumber++}"

    private fun execute(command: Command): Boolean =
        try {
            history.execute(command)
            message = null
            publish()
            true
        } catch (e: CommandException) {
            message = e.message
            publish()
            false
        }

    fun importVideo(sourceUri: String, durationMs: Long?) {
        if (durationMs == null || durationMs < Clip.MIN_CLIP_MS) {
            message = "Could not read this video's length."
            publish()
            return
        }
        val clip = Clip(newClipId(), sourceUri, durationMs, 0L, durationMs)
        if (execute(AddClip(clip))) {
            selectedClipId = clip.id
            publish()
        }
    }

    fun select(clipId: String?) {
        selectedClipId = clipId
        publish()
    }

    fun trimSelected(newInMs: Long, newOutMs: Long): Boolean {
        val id = selectedClipId ?: return false
        return execute(TrimClip(id, newInMs, newOutMs))
    }

    /** Splits whichever clip is under [timelineMs]. */
    fun splitAt(timelineMs: Long) {
        val location = history.current.locate(timelineMs)
        if (location == null) {
            message = "Nothing to split."
            publish()
            return
        }
        execute(SplitClip(location.clip.id, location.clip.inMs + location.offsetMs, newClipId()))
    }

    fun deleteSelected() {
        val id = selectedClipId
        if (id == null) {
            message = "Select a clip first."
            publish()
            return
        }
        execute(DeleteClip(id))
    }

    fun undo() {
        history.undo()
        message = null
        publish()
    }

    fun redo() {
        history.redo()
        message = null
        publish()
    }

    fun beginExport(): Boolean {
        if (export == ExportState.Running || history.current.mainTrack.clips.isEmpty()) return false
        export = ExportState.Running
        message = null
        publish()
        return true
    }

    fun finishExport(result: Result<String>) {
        export = result.fold(
            onSuccess = { ExportState.Done },
            onFailure = { ExportState.Failed(it.message ?: it.toString()) },
        )
        publish()
    }
}
