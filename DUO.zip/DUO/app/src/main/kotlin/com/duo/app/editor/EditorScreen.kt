package com.duo.app.editor

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.duo.app.engine.Media3Engine
import com.duo.core.model.Clip
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun formatMs(ms: Long): String =
    "%d:%02d.%d".format(ms / 60_000, (ms / 1000) % 60, (ms % 1000) / 100)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: EditorViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val exo = remember { ExoPlayer.Builder(context).build() }
    var isPlaying by remember { mutableStateOf(false) }
    var playheadMs by remember { mutableLongStateOf(0L) }
    // The clips the player was last loaded with. Playhead maths uses this so it always matches the player's playlist.
    var loadedClips by remember { mutableStateOf<List<Clip>>(emptyList()) }

    DisposableEffect(exo) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }
        }
        exo.addListener(listener)
        onDispose {
            exo.removeListener(listener)
            exo.release()
        }
    }

    val project = state.project
    val clips = project.mainTrack.clips

    // Keep the preview player in sync with the project (preview plays exactly what export will produce).
    LaunchedEffect(clips) {
        if (clips.isEmpty()) {
            exo.clearMediaItems()
            loadedClips = emptyList()
            playheadMs = 0L
        } else {
            val location = project.locate(playheadMs)
            if (location != null) {
                exo.playWhenReady = false
                exo.setMediaItems(Media3Engine.mediaItems(clips), location.index, location.offsetMs)
                exo.prepare()
                loadedClips = clips
            }
        }
    }

    // Playhead polling (every 50 ms).
    LaunchedEffect(exo) {
        while (true) {
            val loaded = loadedClips
            val index = exo.currentMediaItemIndex
            if (loaded.isNotEmpty() && index in loaded.indices) {
                val before = loaded.take(index).sumOf { it.durationMs }
                playheadMs = before + exo.currentPosition.coerceIn(0L, loaded[index].durationMs)
            }
            delay(50)
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val duration = withContext(Dispatchers.IO) { Media3Engine.readDurationMs(context, uri) }
                vm.importVideo(uri.toString(), duration)
            }
        }
    }

    fun seekTimeline(ms: Long) {
        val location = project.locate(ms) ?: return
        exo.seekTo(location.index, location.offsetMs)
        playheadMs = ms.coerceIn(0L, project.durationMs)
        vm.select(location.clip.id)
    }

    val selected = state.selectedClipId?.let { project.findClip(it) }
    val textColor = MaterialTheme.colorScheme.onBackground

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .safeDrawingPadding()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color.Black),
            contentAlignment = Alignment.Center,
        ) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        useController = false
                        player = exo
                    }
                },
                modifier = Modifier.fillMaxSize(),
            )
            if (clips.isEmpty()) Text("Import a video to start", color = Color.White)
        }

        Text("${formatMs(playheadMs)} / ${formatMs(project.durationMs)}", color = textColor)

        Timeline(
            clips = clips,
            selectedId = state.selectedClipId,
            playheadMs = playheadMs,
            onSeek = ::seekTimeline,
        )

        if (selected != null) {
            TrimControls(clip = selected, onTrim = vm::trimSelected)
        }

        state.message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        when (val export = state.export) {
            ExportState.Idle -> Unit
            ExportState.Running -> Text("Exporting... (cannot be cancelled yet)", color = textColor)
            ExportState.Done -> Text("Exported to Movies/DUO", color = textColor)
            is ExportState.Failed -> Text("Export failed: ${export.reason}", color = MaterialTheme.colorScheme.error)
        }

        val pad = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
                modifier = Modifier.weight(1f),
                contentPadding = pad,
            ) { Text("Import", maxLines = 1) }
            Button(
                onClick = {
                    if (exo.isPlaying) {
                        exo.pause()
                    } else {
                        if (exo.playbackState == Player.STATE_ENDED) exo.seekTo(0, 0L)
                        exo.play()
                    }
                },
                enabled = clips.isNotEmpty(),
                modifier = Modifier.weight(1f),
                contentPadding = pad,
            ) { Text(if (isPlaying) "Pause" else "Play", maxLines = 1) }
            Button(
                onClick = { if (vm.beginExport()) Media3Engine.export(context, project) { vm.finishExport(it) } },
                enabled = clips.isNotEmpty() && state.export != ExportState.Running,
                modifier = Modifier.weight(1f),
                contentPadding = pad,
            ) { Text("Export", maxLines = 1) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { vm.splitAt(playheadMs) },
                enabled = clips.isNotEmpty(),
                modifier = Modifier.weight(1f),
                contentPadding = pad,
            ) { Text("Split", maxLines = 1) }
            Button(
                onClick = { vm.deleteSelected() },
                enabled = selected != null,
                modifier = Modifier.weight(1f),
                contentPadding = pad,
            ) { Text("Delete", maxLines = 1) }
            Button(
                onClick = { vm.undo() },
                enabled = state.canUndo,
                modifier = Modifier.weight(1f),
                contentPadding = pad,
            ) { Text("Undo", maxLines = 1) }
            Button(
                onClick = { vm.redo() },
                enabled = state.canRedo,
                modifier = Modifier.weight(1f),
                contentPadding = pad,
            ) { Text("Redo", maxLines = 1) }
        }
    }
}

@Composable
private fun Timeline(
    clips: List<Clip>,
    selectedId: String?,
    playheadMs: Long,
    onSeek: (Long) -> Unit,
) {
    val total = clips.sumOf { it.durationMs }
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)
            .background(MaterialTheme.colorScheme.surface)
            .pointerInput(clips, total) {
                detectTapGestures { offset ->
                    if (total > 0L) onSeek((offset.x / size.width * total).toLong())
                }
            },
    ) {
        Row(Modifier.fillMaxSize()) {
            clips.forEachIndexed { index, clip ->
                val isSelected = clip.id == selectedId
                Box(
                    modifier = Modifier
                        .weight(clip.durationMs.toFloat())
                        .fillMaxHeight()
                        .padding(horizontal = 1.dp)
                        .background(
                            if (isSelected) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.secondaryContainer
                        ),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    Text(
                        "${index + 1}",
                        modifier = Modifier.padding(start = 6.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSecondaryContainer,
                    )
                }
            }
        }
        if (total > 0L) {
            Box(
                Modifier
                    .offset(x = maxWidth * (playheadMs.toFloat() / total))
                    .width(2.dp)
                    .fillMaxHeight()
                    .background(Color.White)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TrimControls(clip: Clip, onTrim: (Long, Long) -> Boolean) {
    var range by remember(clip) { mutableStateOf(clip.inMs.toFloat()..clip.outMs.toFloat()) }
    Column {
        Text(
            "Trim: in ${formatMs(range.start.toLong())}  out ${formatMs(range.endInclusive.toLong())}  (source ${formatMs(clip.sourceDurationMs)})",
            color = MaterialTheme.colorScheme.onBackground,
        )
        RangeSlider(
            value = range,
            onValueChange = { range = it },
            valueRange = 0f..clip.sourceDurationMs.toFloat(),
            onValueChangeFinished = {
                val ok = onTrim(range.start.toLong(), range.endInclusive.toLong())
                if (!ok) range = clip.inMs.toFloat()..clip.outMs.toFloat()
            },
        )
    }
}
