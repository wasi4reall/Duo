package com.duo.core.commands

import com.duo.core.model.Clip
import com.duo.core.model.Project

/** Thrown when a command cannot be applied. The project is left unchanged. */
class CommandException(message: String) : Exception(message)

/**
 * Every edit is a Command. Humans (and later the AI) change a project only through these.
 * apply() must be pure: same project in, same project out, no side effects.
 */
interface Command {
    val label: String
    fun apply(project: Project): Project
}

private fun Project.mainClipIndex(clipId: String): Int {
    val index = mainTrack.clips.indexOfFirst { it.id == clipId }
    if (index < 0) throw CommandException("Clip $clipId was not found")
    return index
}

data class AddClip(val clip: Clip) : Command {
    override val label = "Add clip"
    override fun apply(project: Project): Project {
        if (project.findClip(clip.id) != null) throw CommandException("Clip id ${clip.id} already exists")
        return project.withMainTrackClips(project.mainTrack.clips + clip)
    }
}

data class TrimClip(val clipId: String, val newInMs: Long, val newOutMs: Long) : Command {
    override val label = "Trim clip"
    override fun apply(project: Project): Project {
        val index = project.mainClipIndex(clipId)
        val clip = project.mainTrack.clips[index]
        if (newInMs < 0L) throw CommandException("Trim start cannot be negative")
        if (newOutMs > clip.sourceDurationMs) throw CommandException("Trim end is past the end of the source video")
        if (newOutMs - newInMs < Clip.MIN_CLIP_MS) throw CommandException("A clip must stay at least ${Clip.MIN_CLIP_MS} ms long")
        val clips = project.mainTrack.clips.toMutableList()
        clips[index] = clip.copy(inMs = newInMs, outMs = newOutMs)
        return project.withMainTrackClips(clips)
    }
}

/**
 * Splits a clip in two at a point given in SOURCE time (between its in and out points).
 * The first half keeps the original id; the second half gets [newClipId].
 * The new id is supplied by the caller so undo/redo and tests are predictable.
 */
data class SplitClip(val clipId: String, val splitAtSourceMs: Long, val newClipId: String) : Command {
    override val label = "Split clip"
    override fun apply(project: Project): Project {
        val index = project.mainClipIndex(clipId)
        val clip = project.mainTrack.clips[index]
        if (project.findClip(newClipId) != null) throw CommandException("Clip id $newClipId already exists")
        if (splitAtSourceMs - clip.inMs < Clip.MIN_CLIP_MS || clip.outMs - splitAtSourceMs < Clip.MIN_CLIP_MS) {
            throw CommandException("Split point is too close to the clip edge (minimum ${Clip.MIN_CLIP_MS} ms each side)")
        }
        val first = clip.copy(outMs = splitAtSourceMs)
        val second = clip.copy(id = newClipId, inMs = splitAtSourceMs)
        val clips = project.mainTrack.clips.toMutableList()
        clips[index] = first
        clips.add(index + 1, second)
        return project.withMainTrackClips(clips)
    }
}

data class DeleteClip(val clipId: String) : Command {
    override val label = "Delete clip"
    override fun apply(project: Project): Project {
        val index = project.mainClipIndex(clipId)
        val clips = project.mainTrack.clips.toMutableList()
        clips.removeAt(index)
        return project.withMainTrackClips(clips)
    }
}
