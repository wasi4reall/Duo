# DUO — STATUS

Last updated: 2026-11-06. Read the "Verification" section first.

## Verification (facts)
- NOTHING in this project has been compiled, run, or tested yet.
- The build sandbox has a Java runtime only: no `javac`, Kotlin compiler, Gradle, Android SDK, or network.
- Only check performed: bracket counts balance in all 9 `.kt` files. This does not prove the code compiles.
- Therefore every item below is "written, unverified". Nothing is marked complete.

## Written, unverified
| Area | Files | Expected behaviour | Verified? |
|---|---|---|---|
| Data model (Clip, Track, Project, locate) | `core/.../model/Models.kt` | immutable timeline model, ms units | No |
| Commands (AddClip, TrimClip, SplitClip, DeleteClip) | `core/.../commands/Commands.kt` | pure edits; invalid input throws CommandException, project unchanged | No |
| Undo/redo | `core/.../commands/CommandHistory.kt` | snapshot-based undo/redo | No |
| Unit tests (12) | `core/src/test/.../CoreTests.kt` | cover all commands, locate, undo/redo, failure cases | Not run |
| Midnight theme | `app/.../ui/Theme.kt` | dark colour scheme | No |
| Editor screen | `app/.../editor/EditorScreen.kt` | import, preview, timeline, trim slider, split, delete, undo, redo, play/pause, export | No |
| Media3 engine wrapper | `app/.../engine/Media3Engine.kt` | clipped playlist for preview, Transformer export to Movies/DUO | No |

Test arithmetic (hand-checked): split of a 10 000 ms clip at 4 000 gives 4 000 + 6 000 = 10 000 ms. Trim 2 000..8 000 then split at 5 000 gives (5 000-2 000) = 3 000 and (8 000-5 000) = 3 000, total 6 000 ms.

## How to build and test (on your PC)
1. Install Android Studio (current stable). Open the `DUO` folder (File > Open).
2. Let Gradle sync. The wrapper JAR is not included (cannot be generated here); Studio should download Gradle 9.1.0 from `gradle-wrapper.properties`. If it asks, accept. If sync fails, copy the full error to me.
3. Run core tests: Gradle panel > `core` > Tasks > verification > `test` (or terminal `./gradlew :core:test`).
4. Run the app: connect the phone with USB debugging, choose `app`, press Run.
5. Report back: sync errors, compile errors (exact text), test failures, anything that misbehaves.

## Versions and decisions
Checked by web search (existence only; mutual compatibility NOT tested):
- Media3 1.10.1 (released 2026-05-12). Apache 2.0 licence (from my knowledge, not re-checked).
- Android Gradle Plugin 9.0.1: needs Gradle >= 9.1.0, JDK 17, max API 36.1.
- Kotlin 2.4.10 (appears in official Compose setup docs).
- Compose BOM 2026.06.00 (appears in official docs; a newer 2026.09.00 also exists).
Assumptions (not verified):
- Kotlin 2.4.10 works with AGP 9.0.1. AGP 9 has built-in Kotlin, so the `kotlin-android` plugin is not applied.
- BOM 2026.06.00 builds with compileSdk 36 (Compose 1.12+ is documented to need compileSdk 37).
- activity-compose 1.11.0 and lifecycle 2.9.4 are older versions chosen to avoid compileSdk 37 requirements. Not checked.
- Media3 API names in `Media3Engine.kt` (`EditedMediaItemSequence.Builder(vararg)`, `Composition.Builder`, `Transformer.Listener`) are from memory and may need small fixes.

Decisions (simple explanations):
- Time unit is milliseconds, because Media3 clipping and positions use ms. Limit: not frame-accurate.
- Undo stores a copy of the project before each command. Simple and safe; fine for small projects.
- Commands are the only way to edit. The AI will later produce the same commands for human approval.
- `core` is a plain Kotlin module with no Android code, so its tests run on a PC in seconds.
- minSdk 29 (Android 10), changed from the 26 I suggested, so saving to Movies/ needs no storage permission. Cost: excludes Android 8-9 phones.
- DeleteClip was added to the requested set because splitting is not useful without removing a piece.
- Preview plays the same clipped playlist that export uses, so preview and export should match.

## Outstanding for Milestone 1 (after first build succeeds)
- Fix whatever compile errors appear.
- Run and pass the unit tests.
- Manual test on device 220333QAG: import, play, split, trim, delete, undo/redo, export; check the exported file in the gallery.

## Known limitations
- Single video track, clips play back-to-back, no gaps, no moving/reordering clips yet.
- Trim uses a slider on the selected clip, not drag handles on the timeline.
- No save/load: the project is lost when the app closes.
- Export cannot be cancelled and shows no progress bar.
- Imported video URIs from the photo picker may stop working after the app restarts (irrelevant until save/load exists).
- Only the Midnight theme exists. Light, Neon, Custom, navigation and project settings are not built.
- App icon is the system default. Audio, text, effects, transitions, keyframes, AI, learning and collaboration: not started.
- Rotating the phone recreates the screen and resets the playhead to the start.
