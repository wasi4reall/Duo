package com.duo.core.model

/**
 * One piece of a source video placed on a track.
 * Times are in milliseconds. [inMs]..[outMs] is the part of the source that is kept.
 */
data class Clip(
    val id: String,
    val sourceUri: String,
    val sourceDurationMs: Long,
    val inMs: Long,
    val outMs: Long,
) {
    init {
        require(inMs >= 0L) { "inMs must be >= 0" }
        require(outMs - inMs >= MIN_CLIP_MS) { "clip must be at least $MIN_CLIP_MS ms long" }
        require(outMs <= sourceDurationMs) { "outMs must not exceed the source duration" }
    }

    val durationMs: Long get() = outMs - inMs

    companion object {
        const val MIN_CLIP_MS = 100L
    }
}

/** A list of clips played one after another (no gaps in Milestone 1). */
data class Track(
    val id: String,
    val clips: List<Clip> = emptyList(),
) {
    val durationMs: Long get() = clips.sumOf { it.durationMs }
}

/** Where a timeline time falls: which clip, and how far into that clip. */
data class ClipLocation(
    val index: Int,
    val clip: Clip,
    val offsetMs: Long,
)

/** The whole editable project. Immutable: every edit produces a new Project. */
data class Project(
    val tracks: List<Track>,
) {
    init {
        require(tracks.isNotEmpty()) { "a project needs at least one track" }
    }

    val mainTrack: Track get() = tracks[0]
    val durationMs: Long get() = mainTrack.durationMs

    fun findClip(id: String): Clip? =
        tracks.firstNotNullOfOrNull { track -> track.clips.firstOrNull { it.id == id } }

    fun withMainTrackClips(clips: List<Clip>): Project =
        copy(tracks = listOf(mainTrack.copy(clips = clips)) + tracks.drop(1))

    /** Start time of the clip at [index] on the timeline. */
    fun clipStartMs(index: Int): Long = mainTrack.clips.take(index).sumOf { it.durationMs }

    /** Finds the clip at a timeline time. Times outside the project are clamped. */
    fun locate(timelineMs: Long): ClipLocation? {
        val clips = mainTrack.clips
        if (clips.isEmpty()) return null
        val t = timelineMs.coerceIn(0L, durationMs)
        var start = 0L
        for ((i, clip) in clips.withIndex()) {
            val end = start + clip.durationMs
            if (t < end || i == clips.lastIndex) {
                return ClipLocation(i, clip, (t - start).coerceAtMost(clip.durationMs))
            }
            start = end
        }
        return null
    }

    companion object {
        const val MAIN_TRACK_ID = "main"
        fun empty(): Project = Project(listOf(Track(MAIN_TRACK_ID)))
    }
}
