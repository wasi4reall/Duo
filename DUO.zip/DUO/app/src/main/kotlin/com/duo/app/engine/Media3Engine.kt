package com.duo.app.engine

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.duo.core.model.Clip
import com.duo.core.model.Project
import java.io.File

/**
 * The only place that talks to Media3 for preview items and export.
 * The rest of DUO uses its own Project model, so this file is what we replace
 * if we ever outgrow Media3 (the "hybrid" plan).
 */
@OptIn(UnstableApi::class)
object Media3Engine {

    private var runningTransformer: Transformer? = null

    fun mediaItem(clip: Clip): MediaItem =
        MediaItem.Builder()
            .setUri(clip.sourceUri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(clip.inMs)
                    .setEndPositionMs(clip.outMs)
                    .build()
            )
            .build()

    fun mediaItems(clips: List<Clip>): List<MediaItem> = clips.map(::mediaItem)

    /** Reads a video's length in ms. Returns null if it cannot be read. */
    fun readDurationMs(context: Context, uri: Uri): Long? {
        val retriever = android.media.MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
        } catch (e: Exception) {
            null
        } finally {
            retriever.release()
        }
    }

    /**
     * Exports the main track to Movies/DUO. Must be called from the main thread.
     * [onResult] is always delivered on the main thread.
     */
    fun export(context: Context, project: Project, onResult: (Result<String>) -> Unit) {
        val appContext = context.applicationContext
        val main = Handler(Looper.getMainLooper())
        val clips = project.mainTrack.clips
        if (clips.isEmpty()) {
            onResult(Result.failure(IllegalStateException("Nothing to export")))
            return
        }
        val items = clips.map { EditedMediaItem.Builder(mediaItem(it)).build() }
        val sequence = EditedMediaItemSequence.Builder(*items.toTypedArray()).build()
        val composition = Composition.Builder(sequence).build()
        val tempFile = File(appContext.cacheDir, "duo_export_${System.currentTimeMillis()}.mp4")

        val transformer = Transformer.Builder(appContext)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    runningTransformer = null
                    // Copying a large file must not block the UI thread.
                    Thread {
                        val result = runCatching { saveToMovies(appContext, tempFile).toString() }
                        tempFile.delete()
                        main.post { onResult(result) }
                    }.start()
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException,
                ) {
                    runningTransformer = null
                    tempFile.delete()
                    onResult(Result.failure(exportException))
                }
            })
            .build()
        runningTransformer = transformer
        transformer.start(composition, tempFile.absolutePath)
    }

    private fun saveToMovies(context: Context, file: File): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "DUO_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/DUO")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Could not create a gallery entry")
        val out = resolver.openOutputStream(uri) ?: error("Could not open the gallery entry")
        out.use { stream -> file.inputStream().use { it.copyTo(stream) } }
        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        return uri
    }
}
