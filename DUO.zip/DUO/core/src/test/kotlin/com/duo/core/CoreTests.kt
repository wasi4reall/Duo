package com.duo.core

import com.duo.core.commands.AddClip
import com.duo.core.commands.CommandException
import com.duo.core.commands.CommandHistory
import com.duo.core.commands.DeleteClip
import com.duo.core.commands.SplitClip
import com.duo.core.commands.TrimClip
import com.duo.core.model.Clip
import com.duo.core.model.Project
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class CoreTests {

    private fun clip(id: String = "a", duration: Long = 10_000L) =
        Clip(id, "content://video/$id", duration, 0L, duration)

    private fun projectWith(vararg clips: Clip): Project {
        var p = Project.empty()
        for (c in clips) p = AddClip(c).apply(p)
        return p
    }

    @Test
    fun clipRejectsInvalidRange() {
        assertFailsWith<IllegalArgumentException> { Clip("x", "u", 1000L, 500L, 500L) }
        assertFailsWith<IllegalArgumentException> { Clip("x", "u", 1000L, 0L, 2000L) }
        assertFailsWith<IllegalArgumentException> { Clip("x", "u", 1000L, -1L, 500L) }
    }

    @Test
    fun addClipAppendsAndRejectsDuplicateId() {
        val p = projectWith(clip("a"))
        assertEquals(1, p.mainTrack.clips.size)
        assertEquals(10_000L, p.durationMs)
        assertFailsWith<CommandException> { AddClip(clip("a")).apply(p) }
    }

    @Test
    fun trimChangesInAndOut() {
        val p = TrimClip("a", 1_000L, 6_000L).apply(projectWith(clip("a")))
        val c = p.findClip("a")!!
        assertEquals(1_000L, c.inMs)
        assertEquals(6_000L, c.outMs)
        assertEquals(5_000L, p.durationMs)
    }

    @Test
    fun trimRejectsInvalidValues() {
        val p = projectWith(clip("a"))
        assertFailsWith<CommandException> { TrimClip("a", -1L, 5_000L).apply(p) }
        assertFailsWith<CommandException> { TrimClip("a", 0L, 10_001L).apply(p) }
        assertFailsWith<CommandException> { TrimClip("a", 5_000L, 5_050L).apply(p) }
        assertFailsWith<CommandException> { TrimClip("missing", 0L, 5_000L).apply(p) }
    }

    @Test
    fun splitMakesTwoClipsWithSameTotalDuration() {
        val p = SplitClip("a", 4_000L, "b").apply(projectWith(clip("a")))
        val clips = p.mainTrack.clips
        assertEquals(listOf("a", "b"), clips.map { it.id })
        assertEquals(0L, clips[0].inMs)
        assertEquals(4_000L, clips[0].outMs)
        assertEquals(4_000L, clips[1].inMs)
        assertEquals(10_000L, clips[1].outMs)
        assertEquals(10_000L, p.durationMs)
    }

    @Test
    fun splitRespectsAnAlreadyTrimmedClip() {
        val trimmed = TrimClip("a", 2_000L, 8_000L).apply(projectWith(clip("a")))
        val p = SplitClip("a", 5_000L, "b").apply(trimmed)
        assertEquals(3_000L, p.findClip("a")!!.durationMs)
        assertEquals(3_000L, p.findClip("b")!!.durationMs)
        assertEquals(6_000L, p.durationMs)
    }

    @Test
    fun splitRejectsPointsNearOrOutsideEdges() {
        val p = projectWith(clip("a"))
        assertFailsWith<CommandException> { SplitClip("a", 50L, "b").apply(p) }
        assertFailsWith<CommandException> { SplitClip("a", 9_950L, "b").apply(p) }
        assertFailsWith<CommandException> { SplitClip("a", 20_000L, "b").apply(p) }
        assertFailsWith<CommandException> { SplitClip("a", 5_000L, "a").apply(p) }
    }

    @Test
    fun deleteRemovesClip() {
        val p = DeleteClip("a").apply(projectWith(clip("a"), clip("b", 5_000L)))
        assertEquals(listOf("b"), p.mainTrack.clips.map { it.id })
        assertNull(p.findClip("a"))
        assertFailsWith<CommandException> { DeleteClip("zzz").apply(p) }
    }

    @Test
    fun locateFindsClipAndOffset() {
        val p = projectWith(clip("a", 1_000L), clip("b", 2_000L))
        val inFirst = assertNotNull(p.locate(400L))
        assertEquals(0, inFirst.index)
        assertEquals(400L, inFirst.offsetMs)
        val inSecond = assertNotNull(p.locate(1_500L))
        assertEquals(1, inSecond.index)
        assertEquals(500L, inSecond.offsetMs)
        val atEnd = assertNotNull(p.locate(99_999L))
        assertEquals(1, atEnd.index)
        assertEquals(2_000L, atEnd.offsetMs)
        assertNull(Project.empty().locate(0L))
    }

    @Test
    fun undoAndRedoRestoreExactStates() {
        val h = CommandHistory()
        val empty = h.current
        h.execute(AddClip(clip("a")))
        val afterAdd = h.current
        h.execute(SplitClip("a", 4_000L, "b"))
        val afterSplit = h.current
        assertTrue(h.canUndo)
        assertFalse(h.canRedo)

        assertEquals(afterAdd, h.undo())
        assertEquals(empty, h.undo())
        assertFalse(h.canUndo)
        assertNull(h.undo())
        assertTrue(h.canRedo)

        assertEquals(afterAdd, h.redo())
        assertEquals(afterSplit, h.redo())
        assertNull(h.redo())
    }

    @Test
    fun newCommandClearsRedo() {
        val h = CommandHistory()
        h.execute(AddClip(clip("a")))
        h.undo()
        assertTrue(h.canRedo)
        h.execute(AddClip(clip("c")))
        assertFalse(h.canRedo)
    }

    @Test
    fun failedCommandChangesNothing() {
        val h = CommandHistory()
        h.execute(AddClip(clip("a")))
        val before = h.current
        assertFailsWith<CommandException> { h.execute(TrimClip("a", 0L, 99_999L)) }
        assertEquals(before, h.current)
        h.undo()
        assertEquals(Project.empty(), h.current)
        assertFalse(h.canUndo)
    }
}
