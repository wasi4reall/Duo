package com.duo.core.commands

import com.duo.core.model.Project

/**
 * Runs commands and remembers them for undo/redo.
 * Undo works by remembering the project as it was before each command (a "snapshot").
 * Because Project is immutable this is cheap and cannot drift out of sync.
 */
class CommandHistory(initial: Project = Project.empty()) {

    private class Entry(val command: Command, val before: Project, val after: Project)

    private val undoStack = ArrayDeque<Entry>()
    private val redoStack = ArrayDeque<Entry>()

    var current: Project = initial
        private set

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    /** Applies [command]. Throws CommandException (and changes nothing) if it is invalid. */
    fun execute(command: Command): Project {
        val after = command.apply(current)
        undoStack.addLast(Entry(command, current, after))
        redoStack.clear()
        current = after
        return after
    }

    fun undo(): Project? {
        val entry = undoStack.removeLastOrNull() ?: return null
        redoStack.addLast(entry)
        current = entry.before
        return current
    }

    fun redo(): Project? {
        val entry = redoStack.removeLastOrNull() ?: return null
        undoStack.addLast(entry)
        current = entry.after
        return current
    }
}
